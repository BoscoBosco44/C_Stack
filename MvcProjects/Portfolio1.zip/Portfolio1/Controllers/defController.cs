using Microsoft.AspNetCore.Mvc;

namespace Portfolio1Namespace.Controllers;

public class DefController : Controller {

    [HttpGet]
    [Route("")]
    public string Index() {
        return "hello World from defController";
    }

    //----------------

    [HttpGet]
    [Route("projects")]
    public string Projects() {
        return "These are my projects";
    }

    //---------------

    [HttpGet]
    [Route("contact")]
    public string Contact() {
        return "This is my contact info";
    }
}