//attack name
//damageAmount
//constructor: specify ^ on creation

class Attack {
    public string Name;
    int damageAmount;

    public Attack(string name, int da) {
        Name = name;
        damageAmount = da;
    }
}